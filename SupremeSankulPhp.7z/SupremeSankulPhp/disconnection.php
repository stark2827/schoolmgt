<?php
mysql_close();